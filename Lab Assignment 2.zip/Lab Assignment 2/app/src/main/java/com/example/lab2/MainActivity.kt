package com.example.lab2
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerview: RecyclerView = findViewById(R.id.recyclerview)

        val adapter = ArticlesAdapter(getArticles())
        recyclerview.adapter=adapter
        val manager=LinearLayoutManager(this)
        recyclerview.layoutManager= manager
    }

    fun getArticles(): List<Article> {
        val articles = ArrayList<Article>()

        articles.add(Article("Toyota Supra", "September 24, 2024", R.drawable.image1, "A powerful sports car with stunning design and top-notch performance."))
        articles.add(Article("Ford Mustang", "Date 2, 2024", R.drawable.image5, "An iconic muscle car that blends classic design with modern technology."))
        articles.add(Article("Tesla Model S", "Date 3, 2024", R.drawable.image3, "A luxury electric sedan with exceptional range and advanced autonomous features."))
        articles.add(Article("Chevrolet Camaro", "Date 4, 2024", R.drawable.image4, "A high-performance car combining agility, speed, and comfort."))
        articles.add(Article("BMW M3", "Date 5, 2024", R.drawable.image5, "A dynamic sports sedan offering a perfect mix of power and luxury."))
        articles.add(Article("Audi R8", "Date 6, 2024", R.drawable.image6, "A supercar experience with a roaring V10 engine and advanced features."))
        articles.add(Article("Nissan GT-R", "Date 7, 2024", R.drawable.image7, "A high-performance car with thrilling acceleration and impressive handling."))
        articles.add(Article("Mercedes-Benz G-Wagon", "Date 8, 2024", R.drawable.image8, "A luxurious off-roader with timeless styling and cutting-edge features."))
        articles.add(Article("Honda Civic Type R", "Date 9, 2024", R.drawable.image9, "A sporty hatchback with aggressive looks and a turbocharged engine."))
        articles.add(Article("Porsche 911", "Date 10, 2024", R.drawable.image10, "An iconic sports car with timeless design and unmatched driving dynamics."))
        articles.add(Article("Range Rover Sport", "Date 11, 2024", R.drawable.image11, "A versatile luxury SUV that balances performance, comfort, and off-road capability."))
        articles.add(Article("Lamborghini Huracan", "Date 12, 2024", R.drawable.image12, "A stunning supercar with a powerful V10 engine and thrilling speed."))
        articles.add(Article("Ferrari F8 Tributo", "Date 13, 2024", R.drawable.image13, "A high-performance Ferrari with incredible aerodynamics and stunning looks."))
        articles.add(Article("Jeep Wrangler", "Date 14, 2024", R.drawable.image14, "An iconic off-road vehicle designed for adventure and rugged terrain."))
        articles.add(Article("Mazda MX-5 Miata", "Date 15, 2024", R.drawable.image12, "A lightweight roadster known for its fun driving experience and agility."))
        articles.add(Article("Volkswagen Golf GTI", "Date 16, 2024", R.drawable.image1, "A hot hatch offering a balance of everyday usability and sporty performance."))
        articles.add(Article("Subaru WRX STI", "Date 17, 2024", R.drawable.image7, "A rally-inspired car with all-wheel drive and powerful turbocharged engine."))
        articles.add(Article("Aston Martin Vantage", "Date 18, 2024", R.drawable.image5, "A luxury sports car offering a mix of elegant design and thrilling performance."))
        articles.add(Article("Alfa Romeo Giulia Quadrifoglio", "Date 19, 2024", R.drawable.image6, "A sporty sedan with Italian design and an impressive twin-turbo V6 engine."))
        articles.add(Article("Ford Bronco", "Date 20, 2024", R.drawable.image3, "A rugged off-road SUV that brings back the spirit of adventure."))

        return articles
    }

}