package com.example.lab2

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.TextView
import android.widget.ImageView

class ArticleDetailsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_article_details)

        val title: String? = intent.getStringExtra("title")
        val date: String? = intent.getStringExtra("date")
        val details: String? = intent.getStringExtra("details")
        val image: Int = intent.getIntExtra("image", R.drawable.image1)

        findViewById<TextView>(R.id.textView_name).text = title
        findViewById<TextView>(R.id.textView_date).text = date
        findViewById<TextView>(R.id.textView_detail).text = details
        findViewById<ImageView>(R.id.image_start).setImageResource(image)
    }
}